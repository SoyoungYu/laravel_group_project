jQuery('#japan_week1').click(function () {
    if ($('#japan_week1Hidden').css("display") == "none") {
        jQuery('#japan_week1Hidden').show();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').hide();
    } else {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').hide();
    }
});

jQuery('#japan_week2').click(function () {
    if ($('#japan_week2Hidden').css("display") == "none") {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').show();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').hide();
    } else {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').hide();
    }
});

jQuery('#japan_week3').click(function () {
    if ($('#japan_week3Hidden').css("display") == "none") {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').show();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').hide();
    } else {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').hide();
    }
});

jQuery('#japan_week4').click(function () {
    if ($('#japan_week4Hidden').css("display") == "none") {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').show();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').hide();
    } else {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').hide();
    }
});

jQuery('#japan_week5').click(function () {
    if ($('#japan_week5Hidden').css("display") == "none") {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').show();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').hide();
    } else {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').hide();
    }
});

jQuery('#japan_week6').click(function () {
    if ($('#japan_week6Hidden').css("display") == "none") {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').show();
        jQuery('#japan_week7Hidden').hide();
    } else {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').hide();
    }
});

jQuery('#japan_week7').click(function () {
    if ($('#japan_week7Hidden').css("display") == "none") {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').show();
    } else {
        jQuery('#japan_week1Hidden').hide();
        jQuery('#japan_week2Hidden').hide();
        jQuery('#japan_week3Hidden').hide();
        jQuery('#japan_week4Hidden').hide();
        jQuery('#japan_week5Hidden').hide();
        jQuery('#japan_week6Hidden').hide();
        jQuery('#japan_week7Hidden').hide();
    }
});

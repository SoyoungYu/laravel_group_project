@extends('layouts.master')
@section('title')
    team8
@endsection

@section('content')
    <div id="app">
        <app><app>
    </div>
    <script src="{{ asset('js/app.js') }}"></script>
    <script src="js/japan.js"></script>
    <script src="js/member.js"></script>
@endsection
<?php $__env->startSection('title'); ?>
    team8
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="app">
        <app><app>
    </div>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="js/japan.js"></script>
    <script src="js/member.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DevelopLaravel\team_project\team_project_8\resources\views/home.blade.php ENDPATH**/ ?>